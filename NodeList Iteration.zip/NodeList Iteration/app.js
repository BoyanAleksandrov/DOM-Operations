function deleteByID() {

    let input = document.getElementsByTagName("input")[0];
    var result = document.getElementById("result");
    let table = document.querySelector("#employees");
    let allTds = table.querySelectorAll("td");
    
 for(const value of allTds.values()){
   
   if(value.innerText == input.value){
    result.textContent = "Found";
    break;
   }
   else{
    result.textContent = "Not Found";
   }
    
 }
    
}